//=============================================================================
// Console_fixes.js
//=============================================================================
/*:
 * @plugindesc Fixes all sorts of stuff
 *
 * @author Me, myself and I.
 *
 * @help
 *
 * 
 *
 * TERMS OF USE
 * Just don't.
 *
 */
 
  BattleManager.getActorInputOrder = function() {
    let members = $gameParty.members();
  
    // separate members into an array of arrays each containing only their index agility, and dead status
    let list = members.map((el, index) => [index, el.agi, el.isAlive() && el.isBattleMember()])
    // sort by agility (sort is performed in place so no need to reassign list)
    list.sort((a, b) => b[1] > a[1])
    // remove dead members
    list = list.filter(_ => _[2])
    // reduce array to just the indexes
    return list.map(_ => _[0])
  };

Sprite_ACSBubble.prototype.setBubbleIndex = function(index) {
// Get Bitmap
var bitmap = ImageManager.loadSystem('ACS_Bubble');
// Get Width & Height
var width = bitmap.width / 7, height = bitmap.height / 3;
// Set Bitmap
this.bitmap = bitmap;
var x = (index % 7) * width
var y = Math.floor(index / 7) * height;
this.setFrame(x, y, width, height);
// Set Bubble Index
this._bubbleIndex = index;
// Index Arrow Positions
if ([0, 1, 2, 3].contains(index)) {
  // Set Arrow Positions
  this._arrowPositions = {2: [70, 85], 4: [15, 45], 6: [120, 45], 8: [70, 10]};
} else if ([4, 5, 6].contains(index)) {
  // Set Arrow Positions
  this._arrowPositions = {2: [65, 95], 4: [5, 55], 6: [125, 55], 8: [65, 10]};
} else if ([7, 8, 9].contains(index)) {
  // Set Arrow Positions
  this._arrowPositions = {2: [60, 85], 4: [5, 45], 6: [115, 45], 8: [60, 5]};
} else if ([10, 11, 12].contains(index)) {
  // Set Arrow Positions
  this._arrowPositions = {2: [60, 90], 4: [5, 50], 6: [115, 50], 8: [60, 15]};
};
// Set Arrow Position
this.setArrowDirection(this._arrowDirection);
};

Scene_OmoMenuEquip.prototype.onStatusWindowCancel = function() {

$gameActors.actor(5).forgetSkill(1507);
$gameActors.actor(5).forgetSkill(1508);
$gameActors.actor(5).forgetSkill(1509);
$gameActors.actor(5).forgetSkill(1510);
$gameActors.actor(5).forgetSkill(1511);

let forbiddenskills = [1507, 1508, 1509, 1510, 1511]
for(i = 0; i < $gameActors.actor(5)._skills.length; i++)
{

  _skill = $gameActors.actor(5)._skills[i]

  $gameActors.actor(5)._skills.indexOf(_skill)
  if (forbiddenskills.includes(_skill)) {

    $gameActors.actor(5)._skills.splice(i)
  }
}

for(i = 0; i < $gameActors.actor(5)._equippedSkills.length; i++)
{

  _skill = $gameActors.actor(5)._equippedSkills[i]

  if (forbiddenskills.includes(_skill)) {

    $gameActors.actor(5)._equippedSkills.splice(i)
  }
}

// EQUIP SKILLS HERE
$gameActors.actor(5).equipSkill(0, 1503)
$gameActors.actor(5).equipSkill(1, 1504)
$gameActors.actor(5).equipSkill(2, 1505)
$gameActors.actor(5).equipSkill(3, 1506)

switch($gameActors._data[5]._equips[1]._itemId){
case 120: // TULIP
  $gameActors.actor(5).learnSkill(1507);
  break
case 121: // GLADIOLUS
  $gameActors.actor(5).learnSkill(1508);
  break
case 122: // CACTUS
  $gameActors.actor(5).learnSkill(1509);
  break
case 123: // ROSE
  $gameActors.actor(5).learnSkill(1510);
  break
case 77: // FLOWER CROWN
  $gameActors.actor(5).learnSkill(1511);
  break
}
this.popScene();
this._statusWindow.deselect();
this._statusWindow.deactivate();
SceneManager._nextScene._commandWindow = this._commandWindow;
SceneManager._nextScene._statusWindow = this._statusWindow;    
};

Window_ChoiceList.prototype.updatePlacement = function() {
// Run Original Function
_TDS_.OmoriBASE.Window_ChoiceList_updatePlacement.call(this);
// Move Window
if ($gameParty.inBattle()) {
  this.x -= 140; this.y -= 69; }
else {
  this.x -= 18; this.y -= 8;
};
var messageY = this._messageWindow.y;
if (messageY >= Graphics.boxHeight / 2) {
  this.y -= 4;
} else {
  this.y += 4;
};
// Get Face Window
var faceWindow = this._messageWindow._faceBoxWindow;
// Set Position based on face window
if (!!$gameMessage.faceCount()) { this.x += faceWindow.x; };
};

Game_Actor.prototype.faceSaveLoad = function() {
var actor = this.actor();
// When changing these the .png should not be required.
switch (actor.id) {
  case 1: // Omori
  return "01_OMORI_BATTLE";
  case 2: // Aubrey
  return "02_AUBREY_BATTLE";
  case 3: // Kel
  return "03_KEL_BATTLE";
  case 4: // Hero
  return "04_HERO_BATTLE";
  case 5: // Basil
  return "05_BASIL_BATTLE";
  case 8: // Omori
  return "01_FA_OMORI_BATTLE";
  case 9: // Aubrey
  return "02_FA_AUBREY_BATTLE";
  case 10: // Kel
  return "03_FA_KEL_BATTLE";
  case 11: // Hero
  return "04_FA_HERO_BATTLE";
  default:
    return "default_face_image_here"; // if ther is one?
}
};